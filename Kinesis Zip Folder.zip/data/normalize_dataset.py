import pandas as pd
from sklearn.preprocessing import MinMaxScaler
# 1. Load the new 500-row synthetic dataset
df = pd.read_csv('synthetic_master_dataset.csv')
# 2. Separate features (numeric) from the Label (text)
X = df.drop(columns=['Label'])
y = df['Label']
# 3. Initialize and Apply the Scaler
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
# 4. Convert back to a DataFrame and verify
X_normalized = pd.DataFrame(X_scaled, columns=X.columns)
# Verification check: Print max values for each column
print("Verification - Maximum values in each column (should all be 1.0):")
print(X_normalized.max())
# 5. Add labels back and save
X_normalized['Label'] = y.values
X_normalized.to_csv('normalized_synthetic_dataset.csv', index=False)
print("\nSuccess! Final normalized dataset saved as 'normalized_synthetic_dataset.csv'")
