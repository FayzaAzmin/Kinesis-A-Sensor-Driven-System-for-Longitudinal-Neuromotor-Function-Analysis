import pandas as pd
import numpy as np
import joblib
from scipy.signal import welch

# 1. LOAD GLOBAL ASSETS ----loaded once when the script starts
try:
    model = joblib.load('parkinsons_model.pkl')
    scaler = joblib.load('scaler.pkl')
except FileNotFoundError:
    print("CRITICAL ERROR: 'parkinsons_model.pkl' or 'scaler.pkl' not found in directory.")
# 2. INTERNAL HELPER FUNCTIONS
def _extract_features(raw_window):
    """Converts raw sensor data into the 18 features the model expects."""
    cols = ['Accel_X', 'Accel_Y', 'Accel_Z', 'Gyro_X', 'Gyro_Y', 'Gyro_Z']
    feature_names = [
        'Accel_X_Mean', 'Accel_X_RMS', 'Accel_X_Peak_Freq',
        'Accel_Y_Mean', 'Accel_Y_RMS', 'Accel_Y_Peak_Freq',
        'Accel_Z_Mean', 'Accel_Z_RMS', 'Accel_Z_Peak_Freq',
        'Gyro_X_Mean', 'Gyro_X_RMS', 'Gyro_X_Peak_Freq',
        'Gyro_Y_Mean', 'Gyro_Y_RMS', 'Gyro_Y_Peak_Freq',
        'Gyro_Z_Mean', 'Gyro_Z_RMS', 'Gyro_Z_Peak_Freq']

    row_features = []
    for col in cols:
        sig = raw_window[col].values
        # Stats
        row_features.append(np.mean(sig))
        row_features.append(np.sqrt(np.mean(sig ** 2)))
        # Frequency (The 'Formula')
        f, p = welch(sig, fs=10.0, nperseg=min(len(sig), 8))
        row_features.append(f[np.argmax(p)])

    return pd.DataFrame([row_features], columns=feature_names)
def _calculate_severity(label, features_df, med_status):
    """Calculates UPDRS 0-4 score based on clinical thresholds."""
    freq = features_df['Accel_X_Peak_Freq'].values[0]
    rms = features_df['Accel_X_RMS'].values[0]
    # 1. Stress/Caffeine Check (Differential Diagnosis)
    if freq > 8.0:
        return 0, "Non-PD Pattern (Possible Stress/Caffeine/Sleep Deprivation)"
    # 2. Score Calculation
    score = 0
    if label == "Tremor":
        if rms < 0.02:
            score = 0
        elif rms < 0.10:
            score = 1
        elif rms < 0.25:
            score = 2
        elif rms < 0.50:
            score = 3
        else:
            score = 4
    elif label == "Tapping":
        if freq >= 2.5:
            score = 0
        elif freq >= 2.0:
            score = 1
        elif freq >= 1.5:
            score = 2
        elif freq >= 1.0:
            score = 3
        else:
            score = 4

    # 3. Medication Context
    note = f"Status: {med_status}"
    if med_status.upper() == "ON" and score > 1:
        note += " - ALERT: Breakthrough symptoms detected while medicated."
    elif med_status.upper() == "OFF":
        note += " - Typical 'Off' state baseline."

    return score, note

# 3. THE CALLABLE FUNCTION
def get_parkinsons_report(file_path, med_status="OFF"):
    try:
        # Load the patient's CSV
        df = pd.read_csv(file_path)
        # Ensure we have at least 1 second of data (10 samples @ 10Hz)
        if len(df) < 10:
            return {"Error": "Data file too short. Need at least 10 rows."}
        window = df.iloc[0:10]
        # A. Feature Extraction
        feat_raw = _extract_features(window)
        # B. Scaling (The Translator)
        feat_scaled = scaler.transform(feat_raw)
        feat_scaled_df = pd.DataFrame(feat_scaled, columns=feat_raw.columns)
        # C. Machine Learning Prediction
        pred = model.predict(feat_scaled_df)[0]
        # D. Clinical Scoring
        score, clinical_note = _calculate_severity(pred, feat_raw, med_status)
        return {
            "Diagnosis": pred,
            "UPDRS_Score": score,
            "Clinical_Note": clinical_note }
    except Exception as e:
        return {"Error": str(e)}

